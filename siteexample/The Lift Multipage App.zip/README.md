
  # The Lift Multipage App  TEST

  This is a code bundle for The Lift Multipage App  TEST. The original project is available at https://www.figma.com/design/sMMx5on7BPrfvh9emg7Kq3/The-Lift-Multipage-App--TEST.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  